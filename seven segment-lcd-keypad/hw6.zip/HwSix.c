#include <stm32f4xx.h>
#include <stdio.h> 
void INIT_PORTA(){
	//clock for GPIOA
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	//MODER PORT A
	GPIOA->MODER = 0x55555555;
}
void INIT_PORTB(){
	//clock for GPIOB
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
	//MODER PORT B
	GPIOB->MODER = 0x55000000;
}
void INIT_PORTC(){
  //clock for GPIOC
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
  //MODER PORT C
  GPIOC->MODER = 0x55555555;
}
void delayMs(int n)
{
for(int i = 0 ; i < n; i++)
for (int j = 0; j < 20000; j++) {}
}
int main(){
INIT_PORTA();
INIT_PORTB();
INIT_PORTC();
int pressed;
unsigned char yekan=0x7F;
unsigned char dahgan=0x66;
unsigned char sadgan=0x3F;
unsigned char hezargan=0x4F;
while(1){
		GPIOA->ODR=yekan;
		GPIOC->ODR=0x1;
		delayMs(10);
		GPIOA->ODR=dahgan;
		GPIOC->ODR=0x2;
		delayMs(10);
		GPIOA->ODR=sadgan;
		GPIOC->ODR=0x4;
		delayMs(10);
		GPIOA->ODR=hezargan;
		GPIOC->ODR=0x8;
		delayMs(10);
		GPIOB->ODR=0xEFFF;
    pressed = GPIOB->IDR;
		switch(pressed){
			case 0xEEFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
						yekan=0X06;
			break;
			case 0xEDFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
						yekan=0X5B;break;
			case 0xEBFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X4F;break;
		}
		GPIOB->ODR = 0XDFFF;
		pressed = GPIOB->IDR;
		switch(pressed){
			case 0xDEFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X66;break;
			case 0xDDFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X6D;break;
			case 0xDBFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X7D;break;
		}
		GPIOB->ODR = 0XBFFF;
		pressed = GPIOB->IDR;
		switch(pressed){
			case 0xBEFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X07;break;
			case 0xBDFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X7F;break;
			case 0xBBFF: 
					hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X6F;break;
		}
		GPIOB->ODR = 0X7FFF;
		pressed = GPIOB->IDR;
		switch(pressed){
			case 0x7DFF: 
				hezargan=sadgan;
						sadgan=dahgan;
						dahgan=yekan;
							yekan=0X3F;break;
		}
	}
}

 